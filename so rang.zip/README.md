# Gimjaban Yield Tracker

App theo dõi hao hụt, thu hồi rong biển Gimjaban — chạy hoàn toàn trên trình duyệt, không cần server, không cần backend.

## Cách deploy lên GitHub Pages (miễn phí, ~5 phút)

1. Tạo repo mới trên GitHub (vào github.com → nút "+" → "New repository").
   - Đặt tên repo bất kỳ, ví dụ `gimjaban-tracker`.
   - Chọn **Public**.
   - Bấm "Create repository".

2. Tải file `index.html` lên repo:
   - Trong repo vừa tạo, bấm **"Add file" → "Upload files"**.
   - Kéo thả file `index.html` vào.
   - Bấm **"Commit changes"**.

3. Bật GitHub Pages:
   - Vào tab **Settings** của repo → mục **Pages** (cột bên trái).
   - Ở "Build and deployment" → **Source**, chọn **"Deploy from a branch"**.
   - **Branch**: chọn `main`, thư mục `/ (root)` → bấm **Save**.

4. Đợi khoảng 1 phút, GitHub sẽ cấp link dạng:
   `https://<tên-tài-khoản>.github.io/gimjaban-tracker/`

5. Mở link đó trên điện thoại, lưu ra màn hình chính (Add to Home Screen) để dùng như một app.

## Lưu ý quan trọng

- Dữ liệu được lưu trong **trình duyệt của thiết bị đang mở app** (localStorage), không đồng bộ qua nhiều thiết bị/nhiều người. Nếu nhiều người cùng dùng (ví dụ điện thoại của tổ trưởng và máy tính văn phòng), mỗi máy sẽ có dữ liệu riêng, không tự gộp lại.
- Nếu xoá lịch sử trình duyệt / cache, dữ liệu trong app cũng sẽ mất — nên dùng tính năng "Xuất CSV" định kỳ để sao lưu.
- Nếu sau này cần dữ liệu dùng chung nhiều người, nhiều thiết bị (đồng bộ thời gian thực), cần nâng cấp lên một backend lưu trữ thật (ví dụ Firebase, Supabase) — lúc đó báo lại để mình bổ sung.

## Cập nhật app sau này

Mỗi khi cần sửa giao diện hoặc logic, chỉ cần thay file `index.html` mới rồi upload đè lên repo (Add file → Upload files → Commit), GitHub Pages sẽ tự cập nhật sau ~1 phút.
